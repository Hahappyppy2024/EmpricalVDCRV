# P07 Test Coverage

## Functional-test ↔ use-case mapping

The benchmark contract contains exactly 12 Version-A use cases. Each use case has exactly one primary functional test file. `FILE13_CrossUseCaseEdgeConditionsTest.php` is auxiliary regression coverage and **is not a thirteenth use case**.

| Use case | Title | Primary functional test |
|---|---|---|
| FILE-01 | Account access | `Functional/FILE01_AccountAccessTest.php` |
| FILE-02 | File upload | `Functional/FILE02_FileUploadTest.php` |
| FILE-03 | Folder management | `Functional/FILE03_FolderManagementTest.php` |
| FILE-04 | File download and preview | `Functional/FILE04_FileDownloadPreviewTest.php` |
| FILE-05 | Sharing links | `Functional/FILE05_SharingLinksTest.php` |
| FILE-06 | Team spaces | `Functional/FILE06_TeamSpacesTest.php` |
| FILE-07 | Search | `Functional/FILE07_SearchTest.php` |
| FILE-08 | Version history | `Functional/FILE08_VersionHistoryTest.php` |
| FILE-09 | Trash and restore | `Functional/FILE09_TrashRestoreTest.php` |
| FILE-10 | Storage quota | `Functional/FILE10_StorageQuotaTest.php` |
| FILE-11 | Audit log and exports | `Functional/FILE11_AuditLogExportsTest.php` |
| FILE-12 | Admin console | `Functional/FILE12_AdminConsoleTest.php` |

Each primary file exercises success behavior plus at least one invalid/authorization boundary required by that use case's acceptance criteria.

## Security suite

The security suite now uses the **32 unique CWE types present in `tests(6).zip`** as the fixed detection dimensions. Each type has one P07-adapted PowerShell test file. The old P07 25-CWE selection is not used in this package.

- Core: 21 CWE types
- P07-specific: 11 CWE types
- Total unique CWE types / primary security files: 32

See `exploit/TEST_COVERAGE.md` and `exploit/test_manifest.json` for the complete mapping.

Security result semantics: `PASS`, `FAIL`, `INCONCLUSIVE`, `N/A`, `ERROR`. A `FAIL` is a vulnerability finding; only `ERROR` indicates test/setup failure.
