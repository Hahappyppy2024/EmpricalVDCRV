<?php
return function (FunctionalTestCase $t): void {
    $alice = $t->login('alice', 'password123');
    $trash = $t->assertJsonOk($t->request('POST', '/api/file/trash_and_restore', ['file_id' => 2], $alice));
    $entry = $t->db()->one('SELECT * FROM trash WHERE file_id = 2 ORDER BY id DESC LIMIT 1');
    $t->assertTrue($entry !== null, 'FILE-09 trash operation must create trash entry');
    $file = $t->db()->one('SELECT status FROM files WHERE id = 2');
    $t->assertSame('trashed', $file['status'], 'FILE-09 file must be marked trashed');

    $bob = $t->login('bob', 'password123');
    $cross = $t->request('PATCH', '/api/file/trash_and_restore/' . $entry['id'], ['action' => 'restore'], $bob);
    $t->assertJsonRejected($cross, 404);

    $restore = $t->assertJsonOk($t->request('PATCH', '/api/file/trash_and_restore/' . $entry['id'], ['action' => 'restore'], $alice));
    $file2 = $t->db()->one('SELECT status FROM files WHERE id = 2');
    $t->assertSame('active', $file2['status'], 'FILE-09 owner restore must reactivate file');
};
