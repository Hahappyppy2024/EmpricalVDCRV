<?php
return function (FunctionalTestCase $t): void {
    $alice = $t->login('alice', 'password123');
    $create = $t->assertJsonOk($t->request('POST', '/api/file/sharing_links', [
        'file_id' => 1, 'scope' => 'public', 'permissions' => 'download', 'expires_at' => '2099-12-31'
    ], $alice), 201);
    $token = (string)$create['token'];
    $share = $t->db()->one('SELECT * FROM shares WHERE token = ?', [$token]);
    $t->assertTrue($share !== null, 'FILE-05 share token must persist');

    $bad = $t->request('POST', '/api/file/sharing_links', ['file_id' => 1, 'scope' => 'world', 'permissions' => 'view'], $alice);
    $t->assertJsonRejected($bad, 422);

    $bob = $t->login('bob', 'password123');
    $cross = $t->request('PATCH', '/api/file/sharing_links/' . $share['id'], ['action' => 'revoke'], $bob);
    $t->assertJsonRejected($cross, 404);

    $t->assertJsonOk($t->request('PATCH', '/api/file/sharing_links/' . $share['id'], ['action' => 'revoke'], $alice));
    $revoked = $t->request('GET', '/s/' . $token);
    $t->assertStatus($revoked, 404, 'FILE-05 revoked share must stop working');
};
