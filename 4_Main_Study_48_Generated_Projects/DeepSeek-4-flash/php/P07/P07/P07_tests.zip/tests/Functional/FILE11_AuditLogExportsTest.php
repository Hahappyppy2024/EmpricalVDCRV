<?php
return function (FunctionalTestCase $t): void {
    $alice = $t->login('alice', 'password123');
    $events = $t->assertJsonOk($t->request('GET', '/api/file/audit_log_and_exports', null, $alice));
    foreach ($events['events'] as $ev) {
        $t->assertSame(2, (int)$ev['user_id'], 'FILE-11 normal user audit listing must be scoped to that user');
    }
    $csv = $t->assertJsonOk($t->request('POST', '/api/file/audit_log_and_exports', ['format' => 'csv'], $alice), 201);
    $t->assertContains('id,actor,action,target_type,target_id,created_at', $csv['content'], 'FILE-11 CSV export must include stable header');

    $admin = $t->login('admin', 'admin123');
    $all = $t->assertJsonOk($t->request('GET', '/api/file/audit_log_and_exports', null, $admin));
    $userIds = array_unique(array_filter(array_map(fn($x) => $x['user_id'] === null ? null : (int)$x['user_id'], $all['events'])));
    $t->assertTrue(count($userIds) >= 2, 'FILE-11 admin should be able to review multi-user audit history');

    $bobEvent = $t->db()->one('SELECT id FROM audit_events WHERE user_id = 3 ORDER BY id LIMIT 1');
    $cross = $t->request('PATCH', '/api/file/audit_log_and_exports/' . $bobEvent['id'], ['metadata' => ['tampered' => true]], $alice);
    $t->assertJsonRejected($cross, 404);
};
