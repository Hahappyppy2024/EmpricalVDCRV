<?php
return function (FunctionalTestCase $t): void {
    $reg = $t->request('POST', '/register', null, null, [
        'username' => 'charlie', 'email' => 'charlie@example.test', 'password' => 'StrongPass123!', 'full_name' => 'Charlie Cloud'
    ]);
    $t->assertStatus($reg, 303, 'FILE-01 valid registration must reach dashboard');
    $t->assertSame('/dashboard', $reg->getHeaderLine('Location'), 'FILE-01 registration redirect mismatch');
    preg_match('/cfss_session=([^;]+)/', $reg->getHeaderLine('Set-Cookie'), $m);
    $t->assertTrue(isset($m[1]), 'FILE-01 registration must create a session');
    $dashboard = $t->request('GET', '/dashboard', null, $m[1]);
    $t->assertStatus($dashboard, 200, 'FILE-01 registered user must reach private dashboard');

    $bad = $t->request('POST', '/login', null, null, ['identifier' => 'alice', 'password' => 'wrong-password']);
    $t->assertStatus($bad, 200, 'FILE-01 incorrect credentials should return controlled login response');
    $t->assertContains('Invalid username or password', (string)$bad->getBody(), 'FILE-01 bad credentials must be rejected');

    $alice = $t->login('alice', 'password123');
    $logout = $t->request('POST', '/logout', null, $alice, []);
    $t->assertStatus($logout, 303, 'FILE-01 logout should redirect to login');
    $after = $t->request('GET', '/api/file/account_access', null, $alice);
    $t->assertStatus($after, 401, 'FILE-01 signed-out session must not access private API');
};
