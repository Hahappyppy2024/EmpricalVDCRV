<?php
return function (FunctionalTestCase $t): void {
    $alice = $t->login('alice', 'password123');
    $history = $t->assertJsonOk($t->request('GET', '/api/file/version_history?file_id=1', null, $alice));
    $t->assertTrue(count($history['versions']) >= 3, 'FILE-08 seed file should expose deterministic version history to owner');

    $new = $t->upload('/api/file/version_history', $alice, ['file_id' => 1, 'comment' => 'functional version'], 'Q3_Report.txt', 'new revision bytes', 'text/plain');
    $j = $t->assertJsonOk($new, 201);
    $newVersion = (int)$j['version'];
    $t->assertTrue($newVersion >= 4, 'FILE-08 new version number must advance');

    $restore = $t->request('PATCH', '/api/file/version_history/1', ['version' => 1], $alice);
    $t->assertJsonOk($restore);
    $file = $t->db()->one('SELECT current_version FROM files WHERE id = 1');
    $t->assertTrue((int)$file['current_version'] > $newVersion, 'FILE-08 restore should create a new current version');

    $bob = $t->login('bob', 'password123');
    $cross = $t->request('GET', '/api/file/version_history?file_id=1', null, $bob);
    $t->assertJsonRejected($cross, 404);
};
