<?php
return function (FunctionalTestCase $t): void {
    $alice = $t->login('alice', 'password123');
    $created = $t->assertJsonOk($t->request('POST', '/api/file/team_spaces', ['name' => 'FunctionalTeam', 'description' => 'test team'], $alice), 201);
    $teamId = (int)$created['id'];
    $list = $t->assertJsonOk($t->request('GET', '/api/file/team_spaces', null, $alice));
    $ids = array_map(fn($x) => (int)$x['id'], $list['teams']);
    $t->assertTrue(in_array($teamId, $ids, true), 'FILE-06 creator must see created team space');

    $bob = $t->login('bob', 'password123');
    $cross = $t->request('PATCH', '/api/file/team_spaces/' . $teamId, ['name' => 'Bob takeover', 'description' => ''], $bob);
    $t->assertJsonRejected($cross, 403);

    $admin = $t->login('admin', 'admin123');
    $add = $t->request('POST', '/api/file/team_spaces', ['action' => 'add_member', 'team_id' => $teamId, 'username' => 'bob', 'role' => 'member'], $admin);
    $t->assertJsonOk($add);
    $membership = $t->db()->one('SELECT * FROM team_members WHERE team_id = ? AND user_id = 3', [$teamId]);
    $t->assertTrue($membership !== null, 'FILE-06 authorized member addition must persist');
};
