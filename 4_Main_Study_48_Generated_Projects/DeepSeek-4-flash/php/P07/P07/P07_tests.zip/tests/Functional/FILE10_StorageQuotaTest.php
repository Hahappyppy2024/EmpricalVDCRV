<?php
return function (FunctionalTestCase $t): void {
    $alice = $t->login('alice', 'password123');
    $mine = $t->assertJsonOk($t->request('GET', '/api/file/storage_quota', null, $alice));
    $t->assertTrue(isset($mine['quota']['quota_bytes'], $mine['quota']['used_bytes']), 'FILE-10 user must see own quota counters');
    $t->assertFalse(isset($mine['quota']['all_users']), 'FILE-10 normal user must not receive all-user quota list');

    $admin = $t->login('admin', 'admin123');
    $all = $t->assertJsonOk($t->request('GET', '/api/file/storage_quota', null, $admin));
    $t->assertTrue(isset($all['quota']['all_users']) && count($all['quota']['all_users']) >= 3, 'FILE-10 admin should see all-user quota state');
    $set = $t->request('PATCH', '/api/file/storage_quota/3', ['quota_bytes' => 100, 'soft_limit' => 100, 'hard_limit' => 100], $admin);
    $t->assertJsonOk($set);

    $bob = $t->login('bob', 'password123');
    $tooLarge = $t->upload('/api/file/file_upload', $bob, ['folder_id' => 3], 'quota.txt', str_repeat('x', 101), 'text/plain');
    $t->assertJsonRejected($tooLarge, 422);
    $cross = $t->request('PATCH', '/api/file/storage_quota/2', ['quota_bytes' => 999999999], $bob);
    $t->assertJsonRejected($cross, 403);
};
