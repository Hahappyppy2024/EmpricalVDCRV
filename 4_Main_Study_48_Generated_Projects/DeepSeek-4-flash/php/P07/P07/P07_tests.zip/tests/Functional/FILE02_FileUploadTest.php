<?php
return function (FunctionalTestCase $t): void {
    $alice = $t->login('alice', 'password123');
    $created = $t->upload('/api/file/file_upload', $alice, [
        'folder_id' => 1, 'description' => 'functional upload', 'tags' => 'functional,test'
    ], 'functional.txt', "hello cloud\n", 'text/plain');
    $j = $t->assertJsonOk($created, 201);
    $fileId = (int)$j['id'];
    $list = $t->assertJsonOk($t->request('GET', '/api/file/file_upload', null, $alice));
    $names = array_column($list['files'], 'name');
    $t->assertTrue(in_array('functional.txt', $names, true), 'FILE-02 uploaded file metadata must persist');

    $before = (int)$t->db()->value('SELECT COUNT(*) FROM files');
    $blocked = $t->upload('/api/file/file_upload', $alice, ['folder_id' => 1], 'blocked.php', '<?php echo 1; ?>', 'application/x-httpd-php');
    $t->assertJsonRejected($blocked, 422);
    $after = (int)$t->db()->value('SELECT COUNT(*) FROM files');
    $t->assertSame($before, $after, 'FILE-02 invalid upload must not leave orphan file records');

    $bob = $t->login('bob', 'password123');
    $cross = $t->request('PATCH', '/api/file/file_upload/' . $fileId, ['description' => 'stolen'], $bob);
    $t->assertJsonRejected($cross, 404);
};
