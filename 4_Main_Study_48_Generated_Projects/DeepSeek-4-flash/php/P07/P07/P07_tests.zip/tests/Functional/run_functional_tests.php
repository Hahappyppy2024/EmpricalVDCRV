<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
require $root . '/vendor/autoload.php';
require __DIR__ . '/FunctionalTestCase.php';

$files = glob(__DIR__ . '/FILE*_Test.php') ?: [];
if (!$files) { $files = glob(__DIR__ . '/FILE*.php') ?: []; }
$files = array_values(array_filter($files, fn($f) => basename($f) !== 'FunctionalTestCase.php' && basename($f) !== 'run_functional_tests.php'));
sort($files);
$results = [];
$passed = 0; $failed = 0; $errors = 0;

foreach ($files as $file) {
    $name = basename($file, '.php');
    $case = null;
    try {
        $case = new FunctionalTestCase($name);
        $test = require $file;
        if (!is_callable($test)) { throw new RuntimeException('Test file must return a callable.'); }
        $test($case);
        $status = 'PASS'; $message = 'All assertions passed.'; $passed++;
    } catch (FunctionalAssertionFailed $e) {
        $status = 'FAIL'; $message = $e->getMessage(); $failed++;
    } catch (Throwable $e) {
        $status = 'ERROR'; $message = get_class($e) . ': ' . $e->getMessage(); $errors++;
    } finally {
        if ($case instanceof FunctionalTestCase) { $case->cleanup(); }
    }
    $results[] = ['test' => $name, 'status' => $status, 'message' => $message];
    printf("[%s] %s - %s\n", $status, $name, $message);
}

$summary = ['project' => 'P07', 'suite' => 'functional', 'passed' => $passed, 'failed' => $failed, 'errors' => $errors, 'total' => count($results), 'results' => $results];
file_put_contents(__DIR__ . '/functional_results.json', json_encode($summary, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
printf("\nFunctional summary: PASS=%d FAIL=%d ERROR=%d TOTAL=%d\n", $passed, $failed, $errors, count($results));
exit(($failed + $errors) === 0 ? 0 : 1);
