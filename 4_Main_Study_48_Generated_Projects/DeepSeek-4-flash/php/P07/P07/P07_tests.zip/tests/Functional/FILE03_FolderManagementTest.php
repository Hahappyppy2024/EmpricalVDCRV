<?php
return function (FunctionalTestCase $t): void {
    $alice = $t->login('alice', 'password123');
    $create = $t->assertJsonOk($t->request('POST', '/api/file/folder_management', ['name' => 'FunctionalFolder', 'parent_id' => 0], $alice), 201);
    $id = (int)$create['id'];
    $t->assertJsonOk($t->request('PATCH', '/api/file/folder_management/' . $id, ['name' => 'RenamedFolder'], $alice));
    $row = $t->db()->one('SELECT * FROM folders WHERE id = ?', [$id]);
    $t->assertSame('RenamedFolder', $row['name'], 'FILE-03 rename must persist');

    $invalid = $t->request('POST', '/api/file/folder_management', ['name' => ''], $alice);
    $t->assertJsonRejected($invalid, 422);

    $bob = $t->login('bob', 'password123');
    $cross = $t->request('PATCH', '/api/file/folder_management/' . $id, ['name' => 'BobRename'], $bob);
    $t->assertJsonRejected($cross, [404,422]);
    $row2 = $t->db()->one('SELECT * FROM folders WHERE id = ?', [$id]);
    $t->assertSame('RenamedFolder', $row2['name'], 'FILE-03 cross-user folder update must not persist');
};
