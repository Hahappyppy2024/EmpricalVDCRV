$ErrorActionPreference = 'Stop'
$ProjectRoot = Resolve-Path (Join-Path $PSScriptRoot '..\..')
Push-Location $ProjectRoot
try {
    & php tests/Functional/run_functional_tests.php
    exit $LASTEXITCODE
} finally {
    Pop-Location
}
