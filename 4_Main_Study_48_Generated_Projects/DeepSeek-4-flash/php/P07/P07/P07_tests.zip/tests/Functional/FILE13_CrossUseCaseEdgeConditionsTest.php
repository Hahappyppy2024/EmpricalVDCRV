<?php
return function (FunctionalTestCase $t): void {
    $privateApis = [
        '/api/file/account_access','/api/file/file_upload','/api/file/folder_management','/api/file/file_download_and_preview',
        '/api/file/sharing_links','/api/file/team_spaces','/api/file/search','/api/file/version_history',
        '/api/file/trash_and_restore','/api/file/storage_quota','/api/file/audit_log_and_exports','/api/file/admin_console'
    ];
    foreach ($privateApis as $path) {
        $t->assertStatus($t->request('GET', $path), 401, 'Cross-use-case edge: unauthenticated API must be denied: ' . $path);
    }
    $alice = $t->login('alice', 'password123');
    $first = $t->request('POST', '/api/file/folder_management', ['name' => 'NoDuplicate'], $alice);
    $t->assertStatus($first, 201);
    $second = $t->request('POST', '/api/file/folder_management', ['name' => 'NoDuplicate'], $alice);
    $t->assertStatus($second, 422, 'Cross-use-case edge: duplicate natural key must not create duplicate folder');
    $body = (string)$t->request('GET', '/api/file/version_history?file_id=999999', null, $alice)->getBody();
    $t->assertFalse(str_contains($body, 'Stack trace') || str_contains($body, '/src/'), 'Cross-use-case edge: stable errors must not expose stack traces or source paths');
};
