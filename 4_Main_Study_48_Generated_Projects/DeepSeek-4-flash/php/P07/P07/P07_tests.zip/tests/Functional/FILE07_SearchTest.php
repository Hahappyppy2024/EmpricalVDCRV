<?php
return function (FunctionalTestCase $t): void {
    $alice = $t->login('alice', 'password123');
    $up = $t->assertJsonOk($t->upload('/api/file/file_upload', $alice, ['folder_id' => 2, 'description' => 'private-only', 'tags' => 'needle-private'], 'OnlyAliceNeedle.txt', 'secret', 'text/plain'), 201);
    $mine = $t->assertJsonOk($t->request('GET', '/api/file/search?q=OnlyAliceNeedle', null, $alice));
    $t->assertSame(1, (int)$mine['count'], 'FILE-07 known search should find matching visible record');

    $bob = $t->login('bob', 'password123');
    $other = $t->assertJsonOk($t->request('GET', '/api/file/search?q=OnlyAliceNeedle', null, $bob));
    $t->assertSame(0, (int)($other['count'] ?? count($other['records'] ?? [])), 'FILE-07 private record must not appear to unauthorized user');

    $empty = $t->assertJsonOk($t->request('GET', '/api/file/search?owner=no_such_owner_987654', null, $alice));
    $t->assertSame(0, (int)($empty['count'] ?? count($empty['records'] ?? [])), 'FILE-07 unmatched filter should return bounded empty result');
};
