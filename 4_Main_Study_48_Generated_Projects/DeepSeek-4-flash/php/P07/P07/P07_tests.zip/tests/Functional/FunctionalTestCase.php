<?php

declare(strict_types=1);

use CloudFS\App;
use CloudFS\Database\Database;
use CloudFS\Database\Seeder;
use CloudFS\Services\AuditService;
use CloudFS\Services\StorageService;
use Psr\Http\Message\ResponseInterface;
use Slim\Psr7\Factory\ServerRequestFactory;
use Slim\Psr7\Factory\StreamFactory;
use Slim\Psr7\UploadedFile;

final class FunctionalAssertionFailed extends RuntimeException {}

final class FunctionalTestCase
{
    private string $root;
    private string $runtime;
    private string $dbPath;
    private string $storagePath;
    private array $config;
    private \Slim\App $app;
    private Database $db;

    public function __construct(string $name)
    {
        $this->root = dirname(__DIR__, 2);
        $safe = preg_replace('/[^A-Za-z0-9_.-]/', '_', $name) ?: 'test';
        $this->runtime = $this->root . '/tests/.runtime/' . $safe;
        $this->resetDirectory($this->runtime);
        $this->dbPath = $this->runtime . '/cloudfs.sqlite';
        $this->storagePath = $this->runtime . '/files';
        @mkdir($this->storagePath, 0775, true);

        $this->db = new Database($this->dbPath);
        $schema = file_get_contents($this->root . '/src/Database/schema.sql');
        if ($schema === false) {
            throw new RuntimeException('Unable to read schema.sql');
        }
        $this->db->pdo()->exec($schema);
        $storage = new StorageService($this->storagePath);
        $audit = new AuditService($this->db);
        (new Seeder($this->db, $storage, $audit))->seed();

        $this->config = [
            'root_dir' => $this->root,
            'app_name' => 'P07 Functional Test App',
            'app_env' => 'test',
            'app_debug' => false,
            'app_host' => '127.0.0.1',
            'app_port' => 8080,
            'db_path' => $this->dbPath,
            'storage_path' => $this->storagePath,
            'session_cookie' => 'cfss_session',
            'session_lifetime' => 7200,
            'ws_host' => '127.0.0.1',
            'ws_port' => 8282,
        ];
        $this->app = App::create($this->config);
    }

    public function db(): Database { return $this->db; }

    public function request(string $method, string $path, ?array $json = null, ?string $cookie = null, ?array $form = null): ResponseInterface
    {
        $factory = new ServerRequestFactory();
        $request = $factory->createServerRequest(strtoupper($method), $path, [
            'REMOTE_ADDR' => '127.0.0.1',
            'HTTP_USER_AGENT' => 'P07-functional-tests',
        ])->withHeader('Accept', 'application/json');
        if ($cookie !== null) {
            $request = $request->withCookieParams(['cfss_session' => $cookie]);
        }
        if ($json !== null) {
            $stream = (new StreamFactory())->createStream(json_encode($json, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
            $request = $request->withBody($stream)->withHeader('Content-Type', 'application/json');
        } elseif ($form !== null) {
            $request = $request->withParsedBody($form)->withHeader('Content-Type', 'application/x-www-form-urlencoded');
        }
        return $this->app->handle($request);
    }

    public function upload(string $path, string $cookie, array $fields, string $filename, string $contents, string $mime = 'text/plain'): ResponseInterface
    {
        $tmp = tempnam($this->runtime, 'upload_');
        if ($tmp === false) { throw new RuntimeException('Unable to create temporary upload file.'); }
        file_put_contents($tmp, $contents);
        $uploaded = new UploadedFile($tmp, $filename, $mime, strlen($contents), UPLOAD_ERR_OK, false);
        $request = (new ServerRequestFactory())->createServerRequest('POST', $path, [
            'REMOTE_ADDR' => '127.0.0.1',
            'HTTP_USER_AGENT' => 'P07-functional-tests',
        ])->withHeader('Accept', 'application/json')
          ->withCookieParams(['cfss_session' => $cookie])
          ->withParsedBody($fields)
          ->withUploadedFiles(['file' => $uploaded]);
        return $this->app->handle($request);
    }

    public function login(string $identifier, string $password): string
    {
        $response = $this->request('POST', '/login', null, null, ['identifier' => $identifier, 'password' => $password]);
        $this->assertSame(303, $response->getStatusCode(), 'Expected successful login redirect.');
        $header = $response->getHeaderLine('Set-Cookie');
        if (!preg_match('/cfss_session=([^;]+)/', $header, $m)) {
            throw new FunctionalAssertionFailed('Successful login did not issue cfss_session cookie.');
        }
        return $m[1];
    }

    public function json(ResponseInterface $response): array
    {
        $decoded = json_decode((string) $response->getBody(), true);
        if (!is_array($decoded)) {
            throw new FunctionalAssertionFailed('Expected JSON response, got: ' . substr((string)$response->getBody(), 0, 300));
        }
        return $decoded;
    }

    public function assertStatus(ResponseInterface $r, int|array $expected, string $message = ''): void
    {
        $allowed = is_array($expected) ? $expected : [$expected];
        if (!in_array($r->getStatusCode(), $allowed, true)) {
            throw new FunctionalAssertionFailed(($message ?: 'Unexpected HTTP status') . ': expected ' . implode('/', $allowed) . ', got ' . $r->getStatusCode() . '; body=' . substr((string)$r->getBody(), 0, 400));
        }
    }

    public function assertTrue(bool $condition, string $message): void
    {
        if (!$condition) { throw new FunctionalAssertionFailed($message); }
    }

    public function assertFalse(bool $condition, string $message): void
    {
        $this->assertTrue(!$condition, $message);
    }

    public function assertSame(mixed $expected, mixed $actual, string $message = ''): void
    {
        if ($expected !== $actual) {
            throw new FunctionalAssertionFailed(($message ?: 'Values differ') . '; expected=' . var_export($expected, true) . ', actual=' . var_export($actual, true));
        }
    }

    public function assertContains(string $needle, string $haystack, string $message): void
    {
        if (!str_contains($haystack, $needle)) { throw new FunctionalAssertionFailed($message . '; missing=' . $needle); }
    }

    public function assertJsonOk(ResponseInterface $r, int|array $status = 200): array
    {
        $this->assertStatus($r, $status);
        $j = $this->json($r);
        $this->assertTrue(($j['ok'] ?? false) === true, 'Expected JSON ok=true.');
        return $j;
    }

    public function assertJsonRejected(ResponseInterface $r, int|array $status = [400,401,403,404,409,422]): array
    {
        $this->assertStatus($r, $status);
        $j = $this->json($r);
        $this->assertFalse(($j['ok'] ?? false) === true, 'Rejected request unexpectedly returned ok=true.');
        return $j;
    }

    public function cleanup(): void { $this->removeTree($this->runtime); }

    private function resetDirectory(string $path): void
    {
        $this->removeTree($path);
        @mkdir($path, 0775, true);
    }

    private function removeTree(string $path): void
    {
        if (!is_dir($path)) { return; }
        $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($path, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST);
        foreach ($it as $entry) { $entry->isDir() ? @rmdir($entry->getPathname()) : @unlink($entry->getPathname()); }
        @rmdir($path);
    }
}
