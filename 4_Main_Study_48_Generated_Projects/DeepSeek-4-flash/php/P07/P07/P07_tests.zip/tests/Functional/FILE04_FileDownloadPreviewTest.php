<?php
return function (FunctionalTestCase $t): void {
    $alice = $t->login('alice', 'password123');
    $op = $t->assertJsonOk($t->request('POST', '/api/file/file_download_and_preview', ['file_id' => 1, 'action' => 'preview'], $alice));
    $t->assertSame('/files/1/preview', $op['url'], 'FILE-04 preview operation should return stable URL');
    $download = $t->request('GET', '/files/1/download', null, $alice);
    $t->assertStatus($download, 200, 'FILE-04 owner should download own active file');
    $t->assertTrue(strlen((string)$download->getBody()) > 0, 'FILE-04 download must return file bytes');

    $bob = $t->login('bob', 'password123');
    $cross = $t->request('GET', '/files/1/download', null, $bob);
    $t->assertStatus($cross, 404, 'FILE-04 users cannot download another user private file by ID');

    $share = $t->request('GET', '/s/seedshare3a1b2');
    $t->assertStatus($share, 200, 'FILE-04 public share recipient should view valid share');
    $shareDownload = $t->request('GET', '/s/seedshare3a1b2/download');
    $t->assertStatus($shareDownload, 200, 'FILE-04 download-enabled public share should download');
};
