<?php
return function (FunctionalTestCase $t): void {
    $admin = $t->login('admin', 'admin123');
    $index = $t->assertJsonOk($t->request('GET', '/api/file/admin_console', null, $admin));
    $t->assertTrue(count($index['users']) >= 3, 'FILE-12 admin console should list managed users');
    $valid = $t->request('PATCH', '/api/file/admin_console/3', ['quota_bytes' => 123456, 'soft_limit' => 100000, 'hard_limit' => 123456], $admin);
    $t->assertJsonOk($valid);
    $invalid = $t->request('PATCH', '/api/file/admin_console/3', ['role' => 'supergod'], $admin);
    $t->assertJsonRejected($invalid, 422);

    $alice = $t->login('alice', 'password123');
    $nonPriv = $t->request('POST', '/api/file/admin_console', ['action' => 'update_policy', 'max_upload_bytes' => 1], $alice);
    $t->assertJsonRejected($nonPriv, 403);
    $unchanged = (string)$t->db()->value("SELECT value FROM settings WHERE key = 'max_upload_bytes'");
    $t->assertSame('52428800', $unchanged, 'FILE-12 non-admin must not change storage policy');
};
