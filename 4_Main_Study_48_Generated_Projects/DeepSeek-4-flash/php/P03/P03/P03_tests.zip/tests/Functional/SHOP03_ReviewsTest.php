<?php
return function (FunctionalTestCase $t): void {
    $customer = $t->login('customer1@example.com', 'customer123');
    $r = $t->request('POST', '/api/shop/reviews', [
        'product_id'=>2,'rating'=>4,'title'=>'Functional review','text'=>'A valid deterministic review.'
    ], $customer);
    $t->assertStatus($r, 201, 'customer creates review');
    $j = $t->json($r);
    $reviewId = (int) ($j['data']['review']['id'] ?? 0);
    $t->assertTrue($reviewId > 0, 'created review id returned');
    $t->assertSame('pending', $j['data']['review']['status'] ?? null, 'new review is pending');

    $r = $t->request('POST', '/api/shop/reviews', [
        'product_id'=>6,'rating'=>8,'text'=>'invalid rating'
    ], $customer);
    $t->assertStatus($r, 422, 'invalid rating rejected');

    $r = $t->request('POST', '/api/shop/reviews', [
        'product_id'=>6,'rating'=>5,'text'=>'no auth'
    ]);
    $t->assertStatus($r, 401, 'unauthenticated review rejected');

    $moderator = $t->login('moderator1@example.com', 'moderator123');
    $r = $t->request('PATCH', "/api/shop/reviews/{$reviewId}", ['decision'=>'approve'], $moderator);
    $t->assertStatus($r, 200, 'moderator approves review');
    $j = $t->json($r);
    $t->assertSame('approved', $j['data']['review']['status'] ?? null, 'moderation state persisted');
};