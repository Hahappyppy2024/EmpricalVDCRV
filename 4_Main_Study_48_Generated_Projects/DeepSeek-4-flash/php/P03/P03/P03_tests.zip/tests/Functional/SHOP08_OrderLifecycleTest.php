<?php
return function (FunctionalTestCase $t): void {
    $customer = $t->login('customer1@example.com', 'customer123');
    $r = $t->request('PATCH', '/api/shop/order_lifecycle/6', ['status'=>'cancelled','comment'=>'functional cancel'], $customer);
    $t->assertStatus($r, 200, 'customer cancels own pending order');
    $j = $t->json($r);
    $t->assertSame('cancelled', $j['data']['order']['status'] ?? null, 'cancelled state persisted');

    $r = $t->request('PATCH', '/api/shop/order_lifecycle/1', ['status'=>'shipped'], $customer);
    $t->assertStatus($r, 403, 'customer cannot ship own order');

    $seller = $t->login('seller1@example.com', 'seller123');
    $r = $t->request('PATCH', '/api/shop/order_lifecycle/1', ['status'=>'shipped','comment'=>'seller shipped'], $seller);
    $t->assertStatus($r, 200, 'seller performs valid lifecycle transition');
    $j = $t->json($r);
    $t->assertSame('shipped', $j['data']['order']['status'] ?? null, 'seller transition persisted');

    $r = $t->request('PATCH', '/api/shop/order_lifecycle/1', ['status'=>'paid'], $seller);
    $t->assertStatus($r, 422, 'invalid reverse lifecycle transition rejected');
};