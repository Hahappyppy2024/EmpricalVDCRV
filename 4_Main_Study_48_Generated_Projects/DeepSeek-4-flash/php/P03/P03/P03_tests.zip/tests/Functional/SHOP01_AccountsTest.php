<?php
return function (FunctionalTestCase $t): void {
    $r = $t->request('POST', '/api/shop/accounts', [
        'email'=>'functional.account@example.com','password'=>'StrongPass123!','name'=>'Functional Account'
    ]);
    $t->assertStatus($r, 201, 'valid registration');
    $j = $t->json($r);
    $t->assertSame('customer', $j['data']['account']['role'] ?? null, 'registration creates customer role');

    $r = $t->request('POST', '/api/shop/accounts', [
        'action'=>'login','email'=>'customer1@example.com','password'=>'wrong-password'
    ]);
    $t->assertStatus($r, 401, 'incorrect credentials rejected');

    $auth = $t->login('customer1@example.com', 'customer123');
    $r = $t->request('GET', '/api/shop/accounts', null, $auth);
    $t->assertStatus($r, 200, 'private account accessible after login');
    $t->assertContains('customer1@example.com', $t->body($r), 'own account returned');

    $r = $t->request('POST', '/api/shop/accounts', ['action'=>'logout'], $auth);
    $t->assertStatus($r, 200, 'logout succeeds');
    $r = $t->request('GET', '/api/shop/customer_data', null, $auth);
    $t->assertStatus($r, 401, 'destroyed session loses private access');
};