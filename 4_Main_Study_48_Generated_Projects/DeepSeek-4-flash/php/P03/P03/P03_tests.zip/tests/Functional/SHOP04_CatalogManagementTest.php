<?php
return function (FunctionalTestCase $t): void {
    $seller1 = $t->login('seller1@example.com', 'seller123');
    $r = $t->request('GET', '/api/shop/catalog_management', null, $seller1);
    $t->assertStatus($r, 200, 'seller product list');
    $t->assertContains('Wireless Headphones', $t->body($r), 'seller sees own product');
    $t->assertNotContains('Smart Watch', $t->body($r), 'seller does not see other seller product');

    $r = $t->request('POST', '/api/shop/catalog_management', [
        'name'=>'Functional Catalog Item','category_id'=>2,'price'=>17.25,'stock'=>7,
        'description'=>'Created by SHOP-04 functional test','active'=>true
    ], $seller1);
    $t->assertStatus($r, 201, 'seller creates product');
    $j = $t->json($r);
    $id = (int) ($j['data']['product']['id'] ?? 0);
    $t->assertTrue($id > 0, 'new product id returned');

    $customer = $t->login('customer1@example.com', 'customer123');
    $r = $t->request('POST', '/api/shop/catalog_management', [
        'name'=>'Forbidden','category_id'=>1,'price'=>1,'stock'=>1
    ], $customer);
    $t->assertStatus($r, 403, 'customer cannot manage catalog');

    $seller2 = $t->login('seller2@example.com', 'seller123');
    $r = $t->request('PATCH', '/api/shop/catalog_management/1', [
        'name'=>'Hijacked','category_id'=>1,'price'=>1,'stock'=>1,'active'=>true
    ], $seller2);
    $t->assertStatus($r, 403, 'seller cannot modify another seller product');
};