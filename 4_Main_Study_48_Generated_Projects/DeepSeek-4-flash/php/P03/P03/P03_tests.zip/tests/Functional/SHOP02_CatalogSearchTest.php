<?php
return function (FunctionalTestCase $t): void {
    $r = $t->request('GET', '/api/shop/catalog_search?keyword=Headphones&category_id=1&max_price=100&in_stock=1');
    $t->assertStatus($r, 200, 'filtered catalog search');
    $j = $t->json($r);
    $results = $j['data']['results'] ?? [];
    $t->assertTrue(count($results) === 1, 'known filters return one matching record');
    $t->assertSame('Wireless Headphones', $results[0]['name'] ?? null, 'matching product returned');

    $r = $t->request('GET', '/api/shop/catalog_search?category_id=999999');
    $t->assertStatus($r, 200, 'out-of-range category is bounded');
    $j = $t->json($r);
    $t->assertTrue(($j['data']['results'] ?? null) === [], 'out-of-range category returns empty list');

    $seller = $t->login('seller1@example.com', 'seller123');
    $r = $t->request('POST', '/api/shop/catalog_management', [
        'name'=>'Hidden Functional Product','category_id'=>1,'price'=>12.5,'stock'=>5,'description'=>'hidden','active'=>false
    ], $seller);
    $t->assertStatus($r, 201, 'seller can create inactive product');

    $r = $t->request('GET', '/api/shop/catalog_search?keyword=Hidden%20Functional%20Product');
    $t->assertStatus($r, 200, 'public search after inactive create');
    $t->assertNotContains('Hidden Functional Product', $t->body($r), 'inactive product not exposed publicly');
};