<?php
return function (FunctionalTestCase $t): void {
    $customer1 = $t->login('customer1@example.com', 'customer123');
    $r = $t->request('POST', '/api/shop/frontend_api_integration', [
        'action'=>'register_client','name'=>'Functional Browser'
    ], $customer1);
    $t->assertStatus($r, 201, 'register frontend client');
    $j = $t->json($r);
    $clientId = (int)($j['data']['client']['id'] ?? 0);
    $t->assertTrue($clientId > 0, 'client id returned');

    $r = $t->request('GET', '/api/shop/frontend_api_integration', null, $customer1);
    $t->assertStatus($r, 200, 'frontend state endpoint');
    $t->assertContains('ws://', $t->body($r), 'websocket URL returned');
    $t->assertContains('ORD-20260001', $t->body($r), 'customer async order state includes own order');

    $customer2 = $t->login('customer2@example.com', 'customer123');
    $r = $t->request('PATCH', "/api/shop/frontend_api_integration/{$clientId}", [
        'name'=>'Hijacked Browser','prefs'=>['theme'=>'dark']
    ], $customer2);
    $t->assertStatus($r, 404, 'another customer cannot update client');

    $r = $t->request('POST', '/api/shop/frontend_api_integration', ['action'=>'unknown'], $customer1);
    $t->assertStatus($r, 422, 'unknown frontend action rejected');
};