<?php
return function (FunctionalTestCase $t): void {
    $seller = $t->login('seller1@example.com', 'seller123');
    $r = $t->request('POST', '/api/shop/seller_and_administrator_operations', [
        'operation'=>'create_promotion','code'=>'FUNC15','description'=>'functional promo',
        'discount_type'=>'percent','amount'=>15,'active'=>'1'
    ], $seller);
    $t->assertStatus($r, 201, 'seller creates promotion');
    $t->assertContains('FUNC15', $t->body($r), 'promotion returned');

    $r = $t->request('POST', '/api/shop/seller_and_administrator_operations', [
        'operation'=>'set_setting','key'=>'currency','value'=>'CAD'
    ], $seller);
    $t->assertStatus($r, 403, 'seller cannot change platform setting');

    $customer = $t->login('customer1@example.com', 'customer123');
    $r = $t->request('GET', '/api/shop/seller_and_administrator_operations', null, $customer);
    $t->assertStatus($r, 403, 'customer cannot enter privileged operations');

    $admin = $t->login('admin@example.com', 'admin123');
    $r = $t->request('POST', '/api/shop/seller_and_administrator_operations', [
        'operation'=>'manage_user','id'=>5,'active'=>false
    ], $admin);
    $t->assertStatus($r, 200, 'admin manages user');
    $j = $t->json($r);
    $t->assertSame(0, (int)($j['data']['user']['active'] ?? 1), 'managed user disabled');
};