<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/vendor/autoload.php';

use Psr\Http\Message\ResponseInterface;
use Slim\Psr7\Factory\ServerRequestFactory;
use Slim\Psr7\Stream;
use Shop\App;
use Shop\SessionManager;

final class FunctionalTestCase
{
    private \Slim\App $app;
    public int $assertions = 0;

    public function __construct(private readonly string $root)
    {
        $this->app = App::create();
    }

    /**
     * @param array<string,mixed>|null $body
     * @param array{token:string,csrf:string}|null $auth
     */
    public function request(string $method, string $path, ?array $body = null, ?array $auth = null, bool $sendCsrf = true): ResponseInterface
    {
        $parts = parse_url($path);
        $uriPath = $parts['path'] ?? $path;
        $request = (new ServerRequestFactory())->createServerRequest($method, $uriPath);

        if (!empty($parts['query'])) {
            parse_str($parts['query'], $query);
            $request = $request->withQueryParams($query);
        }

        $_COOKIE = [];
        if ($auth !== null) {
            $_COOKIE[SessionManager::COOKIE] = $auth['token'];
            $request = $request->withCookieParams([SessionManager::COOKIE => $auth['token']]);
            if ($sendCsrf && !in_array(strtoupper($method), ['GET', 'HEAD', 'OPTIONS'], true)) {
                $request = $request->withHeader('X-CSRF-Token', $auth['csrf']);
            }
        }

        if ($body !== null) {
            $stream = new Stream(fopen('php://temp', 'r+'));
            $stream->write(json_encode($body, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
            $stream->rewind();
            $request = $request->withBody($stream)->withHeader('Content-Type', 'application/json');
        }

        $response = $this->app->handle($request);
        $_COOKIE = [];
        return $response;
    }

    /**
     * @return array{token:string,csrf:string,user:array<string,mixed>}
     */
    public function login(string $email, string $password): array
    {
        $res = $this->request('POST', '/api/shop/accounts', [
            'action' => 'login',
            'email' => $email,
            'password' => $password,
        ]);
        $this->assertStatus($res, 200, "login {$email}");
        $json = $this->json($res);
        $session = $json['data']['session'] ?? [];
        $account = $json['data']['account'] ?? [];
        $this->assertTrue(!empty($session['token']), "session token returned for {$email}");
        $this->assertTrue(!empty($session['csrf_token']), "CSRF token returned for {$email}");
        return [
            'token' => (string) $session['token'],
            'csrf' => (string) $session['csrf_token'],
            'user' => is_array($account) ? $account : [],
        ];
    }

    /** @return array<string,mixed> */
    public function json(ResponseInterface $res): array
    {
        $data = json_decode((string) $res->getBody(), true);
        return is_array($data) ? $data : [];
    }

    public function body(ResponseInterface $res): string
    {
        return (string) $res->getBody();
    }

    public function assertStatus(ResponseInterface $res, int|array $expected, string $label): void
    {
        $this->assertions++;
        $actual = $res->getStatusCode();
        $allowed = is_array($expected) ? $expected : [$expected];
        if (!in_array($actual, $allowed, true)) {
            throw new RuntimeException(
                "{$label}: expected HTTP " . implode('/', $allowed) . ", got {$actual}. Body: " . $this->body($res)
            );
        }
    }

    public function assertTrue(bool $condition, string $label): void
    {
        $this->assertions++;
        if (!$condition) {
            throw new RuntimeException("Assertion failed: {$label}");
        }
    }

    public function assertSame(mixed $expected, mixed $actual, string $label): void
    {
        $this->assertions++;
        if ($expected !== $actual) {
            throw new RuntimeException(
                "{$label}: expected " . var_export($expected, true) . ", got " . var_export($actual, true)
            );
        }
    }

    public function assertContains(string $needle, string $haystack, string $label): void
    {
        $this->assertions++;
        if (!str_contains($haystack, $needle)) {
            throw new RuntimeException("{$label}: expected body to contain " . var_export($needle, true) . ". Body: {$haystack}");
        }
    }

    public function assertNotContains(string $needle, string $haystack, string $label): void
    {
        $this->assertions++;
        if (str_contains($haystack, $needle)) {
            throw new RuntimeException("{$label}: body unexpectedly contains " . var_export($needle, true) . ". Body: {$haystack}");
        }
    }
}
