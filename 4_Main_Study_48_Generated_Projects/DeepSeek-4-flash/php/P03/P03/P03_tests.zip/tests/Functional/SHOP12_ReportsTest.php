<?php
return function (FunctionalTestCase $t): void {
    $seller = $t->login('seller1@example.com', 'seller123');
    $r = $t->request('GET', '/api/shop/reports?type=sales', null, $seller);
    $t->assertStatus($r, 200, 'seller sales report');
    $t->assertContains('"type":"sales"', $t->body($r), 'sales report type returned');

    $r = $t->request('GET', '/api/shop/reports?type=inventory', null, $seller);
    $t->assertStatus($r, 200, 'seller inventory report');

    $r = $t->request('GET', '/api/shop/reports?type=not-a-report', null, $seller);
    $t->assertStatus($r, 400, 'invalid report type rejected');

    $customer = $t->login('customer1@example.com', 'customer123');
    $r = $t->request('GET', '/api/shop/reports?type=sales', null, $customer);
    $t->assertStatus($r, 403, 'customer cannot access privileged reports');
};