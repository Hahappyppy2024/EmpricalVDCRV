<?php
return function (FunctionalTestCase $t): void {
    $seller1 = $t->login('seller1@example.com', 'seller123');
    $r = $t->request('POST', '/api/shop/inventory', ['product_id'=>1,'delta'=>5,'reason'=>'functional restock'], $seller1);
    $t->assertStatus($r, 200, 'seller adjusts own stock');
    $j = $t->json($r);
    $t->assertSame(29, (int)($j['data']['product']['stock'] ?? -1), 'stock adjustment persisted');

    $r = $t->request('POST', '/api/shop/inventory', ['product_id'=>9,'delta'=>1,'reason'=>'forbidden'], $seller1);
    $t->assertStatus($r, 403, 'seller cannot adjust another seller stock');

    $r = $t->request('POST', '/api/shop/inventory', ['product_id'=>1,'delta'=>-1000,'reason'=>'invalid'], $seller1);
    $t->assertStatus($r, 422, 'negative stock prevented');

    $admin = $t->login('admin@example.com', 'admin123');
    $r = $t->request('PATCH', '/api/shop/inventory/9', ['quantity'=>2], $admin);
    $t->assertStatus($r, 200, 'admin may restock seller product');
};