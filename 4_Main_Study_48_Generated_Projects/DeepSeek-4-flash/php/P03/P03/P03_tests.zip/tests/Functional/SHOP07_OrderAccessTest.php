<?php
return function (FunctionalTestCase $t): void {
    $customer1 = $t->login('customer1@example.com', 'customer123');
    $r = $t->request('GET', '/api/shop/order_access?id=1', null, $customer1);
    $t->assertStatus($r, 200, 'customer reads own order');
    $t->assertContains('ORD-20260001', $t->body($r), 'own order returned');

    $r = $t->request('GET', '/api/shop/order_access?id=3', null, $customer1);
    $t->assertStatus($r, 404, 'customer cannot read another customer order');

    $r = $t->request('GET', '/api/shop/order_access', null, $customer1);
    $t->assertStatus($r, 200, 'customer order list');
    $t->assertNotContains('ORD-20260003', $t->body($r), 'other customer order excluded from customer list');

    $admin = $t->login('admin@example.com', 'admin123');
    $r = $t->request('GET', '/api/shop/order_access?id=3', null, $admin);
    $t->assertStatus($r, 200, 'administrator can inspect order');
};