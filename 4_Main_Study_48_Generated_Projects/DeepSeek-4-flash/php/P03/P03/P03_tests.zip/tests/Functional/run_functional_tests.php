<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
require_once __DIR__ . '/FunctionalTestCase.php';

$tests = glob(__DIR__ . '/SHOP*Test.php');
sort($tests);

$results = [];
$failed = 0;
$totalAssertions = 0;

foreach ($tests as $file) {
    $label = basename($file, '.php');

    if (isset($case)) {
        unset($case);
        gc_collect_cycles();
    }

    $cmd = escapeshellarg(PHP_BINARY) . ' ' . escapeshellarg($root . '/bin/reset_db.php');
    $out = [];
    exec($cmd . ' 2>&1', $out, $code);
    if ($code !== 0) {
        echo "[ERROR] {$label}: database reset failed\n";
        echo implode("\n", $out) . "\n";
        $results[] = ['test'=>$label,'status'=>'ERROR','assertions'=>0,'message'=>'database reset failed'];
        $failed++;
        continue;
    }

    try {
        $test = require $file;
        if (!is_callable($test)) {
            throw new RuntimeException('Test file did not return a callable.');
        }
        $case = new FunctionalTestCase($root);
        $test($case);
        $totalAssertions += $case->assertions;
        $results[] = ['test'=>$label,'status'=>'PASS','assertions'=>$case->assertions,'message'=>''];
        echo "[PASS] {$label} ({$case->assertions} assertions)\n";
    } catch (Throwable $e) {
        $failed++;
        $assertions = isset($case) ? $case->assertions : 0;
        $totalAssertions += $assertions;
        $results[] = ['test'=>$label,'status'=>'FAIL','assertions'=>$assertions,'message'=>$e->getMessage()];
        echo "[FAIL] {$label}: {$e->getMessage()}\n";
    }
}

$report = [
    'project'=>'P03 E-commerce System',
    'generated_at'=>date(DATE_ATOM),
    'tests'=>count($results),
    'assertions'=>$totalAssertions,
    'failed'=>$failed,
    'results'=>$results,
];
file_put_contents(__DIR__ . '/functional_results.json', json_encode($report, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));

echo "\nFunctional suite: " . (count($results)-$failed) . " passed, {$failed} failed, {$totalAssertions} assertions.\n";
exit($failed === 0 ? 0 : 1);
