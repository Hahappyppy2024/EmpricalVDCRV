<?php
return function (FunctionalTestCase $t): void {
    $customer = $t->login('customer1@example.com', 'customer123');

    $r = $t->request('POST', '/api/shop/shopping_cart', ['product_id'=>8,'quantity'=>1], $customer);
    $t->assertStatus($r, 422, 'out-of-stock product cannot be added to cart');

    $r = $t->request('POST', '/api/shop/shopping_cart', ['product_id'=>7,'quantity'=>1], $customer);
    $t->assertStatus($r, 201, 'valid product added for payment-decline edge case');

    $r = $t->request('POST', '/api/shop/checkout', [
        'address_id'=>1,'payment_method'=>'card','card_number'=>'4111111111110002'
    ], $customer);
    $t->assertStatus($r, 402, 'deterministic declined card rejected');

    $r = $t->request('GET', '/api/shop/shopping_cart', null, $customer);
    $t->assertStatus($r, 200, 'cart remains readable after declined payment');
    $t->assertContains('Ceramic Mug Set', $t->body($r), 'failed checkout does not clear cart');

    $r = $t->request('POST', '/api/shop/shopping_cart', ['action'=>'remove','cart_id'=>999999], $customer);
    $t->assertStatus($r, 404, 'unknown cart item returns stable not-found');

    $r = $t->request('GET', '/api/shop/order_access?id=999999', null, $customer);
    $t->assertStatus($r, 404, 'unknown order returns stable not-found');
};