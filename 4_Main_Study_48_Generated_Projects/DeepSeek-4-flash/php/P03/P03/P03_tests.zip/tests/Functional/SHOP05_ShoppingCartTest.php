<?php
return function (FunctionalTestCase $t): void {
    $customer1 = $t->login('customer1@example.com', 'customer123');
    $r = $t->request('POST', '/api/shop/shopping_cart', ['product_id'=>1,'quantity'=>2], $customer1);
    $t->assertStatus($r, 201, 'add cart item');
    $j = $t->json($r);
    $items = $j['data']['items'] ?? [];
    $t->assertTrue(count($items) === 1, 'cart has one item');
    $cartId = (int) ($items[0]['cart_id'] ?? $items[0]['id'] ?? 0);
    $t->assertTrue($cartId > 0, 'cart item id returned');

    $r = $t->request('PATCH', "/api/shop/shopping_cart/{$cartId}", ['quantity'=>3], $customer1);
    $t->assertStatus($r, 200, 'update cart quantity');
    $t->assertContains('"quantity":3', $t->body($r), 'updated quantity returned');

    $r = $t->request('POST', '/api/shop/shopping_cart', ['product_id'=>1,'quantity'=>101], $customer1);
    $t->assertStatus($r, 422, 'oversized quantity rejected');

    $customer2 = $t->login('customer2@example.com', 'customer123');
    $r = $t->request('PATCH', "/api/shop/shopping_cart/{$cartId}", ['quantity'=>1], $customer2);
    $t->assertStatus($r, 404, 'cross-user cart item inaccessible');
};