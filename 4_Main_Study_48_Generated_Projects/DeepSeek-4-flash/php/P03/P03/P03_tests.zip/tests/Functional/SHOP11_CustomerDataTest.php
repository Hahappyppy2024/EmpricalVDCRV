<?php
return function (FunctionalTestCase $t): void {
    $customer = $t->login('customer1@example.com', 'customer123');
    $r = $t->request('GET', '/api/shop/customer_data', null, $customer);
    $t->assertStatus($r, 200, 'customer profile returned');
    $t->assertContains('100 Main Street', $t->body($r), 'own seeded address returned');

    $r = $t->request('POST', '/api/shop/customer_data', [
        'action'=>'address','label'=>'Office','line1'=>'55 Functional Road','city'=>'Testville','postal_code'=>'12345','country'=>'US'
    ], $customer);
    $t->assertStatus($r, 201, 'customer creates address');
    $t->assertContains('55 Functional Road', $t->body($r), 'created address returned');

    $r = $t->request('PATCH', '/api/shop/customer_data/5', ['name'=>'Cross User Edit'], $customer);
    $t->assertStatus($r, 403, 'customer cannot edit another customer');

    $admin = $t->login('admin@example.com', 'admin123');
    $r = $t->request('PATCH', '/api/shop/customer_data/5', ['name'=>'Admin Updated Customer'], $admin);
    $t->assertStatus($r, 200, 'admin can update customer data');
    $t->assertContains('Admin Updated Customer', $t->body($r), 'admin update persisted');
};