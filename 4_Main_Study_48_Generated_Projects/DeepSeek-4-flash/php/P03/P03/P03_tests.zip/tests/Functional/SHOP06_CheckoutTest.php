<?php
return function (FunctionalTestCase $t): void {
    $customer = $t->login('customer1@example.com', 'customer123');
    $r = $t->request('POST', '/api/shop/shopping_cart', ['product_id'=>7,'quantity'=>1], $customer);
    $t->assertStatus($r, 201, 'checkout fixture added to cart');

    $r = $t->request('POST', '/api/shop/checkout', [
        'address_id'=>1,'payment_method'=>'card','card_number'=>'4111111111111111','promotion_code'=>'WELCOME10'
    ], $customer);
    $t->assertStatus($r, 201, 'valid checkout creates order');
    $j = $t->json($r);
    $t->assertSame('paid', $j['data']['order']['status'] ?? null, 'approved payment creates paid order');
    $t->assertTrue(((float)($j['data']['order']['total'] ?? 0)) > 0, 'server computes non-zero order total');

    $r = $t->request('POST', '/api/shop/checkout', [
        'address_id'=>1,'payment_method'=>'card','card_number'=>'4111111111111111'
    ], $customer);
    $t->assertStatus($r, 422, 'second checkout on empty cart rejected');
};