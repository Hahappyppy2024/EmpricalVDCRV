$ErrorActionPreference = "Stop"
$root = Resolve-Path (Join-Path $PSScriptRoot "..\..")
Push-Location $root
try {
    php tests/Functional/run_functional_tests.php
    exit $LASTEXITCODE
} finally {
    Pop-Location
}
