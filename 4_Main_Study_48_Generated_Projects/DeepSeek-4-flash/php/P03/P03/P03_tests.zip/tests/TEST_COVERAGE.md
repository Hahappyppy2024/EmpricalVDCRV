# P03 Test Coverage Map

## Functional
SHOP-01 through SHOP-13 remain primary functional tests; SHOP-14 remains auxiliary.

## Security

### Core — 16
CWE-20, CWE-79, CWE-89, CWE-200, CWE-204, CWE-209, CWE-287, CWE-306,
CWE-307, CWE-352, CWE-384, CWE-521, CWE-614, CWE-915, CWE-1004, CWE-1021.

### P03-specific — 7
CWE-284, CWE-434, CWE-639, CWE-840, CWE-862, CWE-863, CWE-1236.

The security list is intentionally based on P03's executable surface.
